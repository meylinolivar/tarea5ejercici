import React, { useState } from "react";

function App() {
  const [tasks, setTasks] = useState([]); // Definimos el estado inicial como un array vacío para guardar las tareas

  // Función que se llama cuando se envía el formulario para agregar una nueva tarea
  const handleFormSubmit = (event) => {
    event.preventDefault(); // Prevenimos el comportamiento por defecto del formulario

    const newTask = event.target.task.value; // Obtenemos el valor del input del formulario

    setTasks([...tasks, newTask]); // Agregamos la nueva tarea al array de tareas utilizando el spread operator
    event.target.reset(); // Reiniciamos el formulario
  };

  // Función que se llama cuando se hace clic en el botón para eliminar una tarea
  const handleDeleteTask = (index) => {
    const updatedTasks = tasks.filter((task, i) => i !== index); // Creamos un nuevo array de tareas excluyendo la tarea que se quiere eliminar
    setTasks(updatedTasks); // Actualizamos el estado con el nuevo array de tareas sin la tarea eliminada
  };

  // Renderizamos la aplicación, que consiste en un formulario para agregar tareas y una lista de tareas con botones para eliminarlas
  return (
    <div>
      <h1>Task List App</h1>
      <form onSubmit={handleFormSubmit}>
        <label htmlFor="task">Add Task:</label>
        <input type="text" id="task" name="task" />
        <button type="submit">Add</button>
      </form>
      <ul>
        {tasks.map((task, index) => (
          <li key={index}>
            {task}{" "}
            <button onClick={() => handleDeleteTask(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
