import React, { useState } from "react";

function ListApp() {
  // Definimos el estado inicial de la lista como un arreglo vacío
  const [list, setList] = useState([]);

  // Definimos el estado inicial del campo de texto del formulario como una cadena vacía
  const [text, setText] = useState("");

  // Función que se llama cuando se envía el formulario para agregar un elemento a la lista
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevenimos el comportamiento predeterminado del formulario para evitar que la página se recargue

    // Agregamos el nuevo elemento a la lista utilizando el estado actual y el valor del campo de texto del formulario
    setList([...list, text]);

    // Reseteamos el valor del campo de texto del formulario a una cadena vacía
    setText("");
  };

  // Función que se llama cuando se cambia el valor del campo de texto del formulario
  const handleChange = (event) => {
    // Actualizamos el valor del campo de texto del formulario utilizando el estado actual y el valor del evento de cambio
    setText(event.target.value);
  };

  // Renderizamos la aplicación, que consiste en una lista de elementos y un formulario para agregar nuevos elementos a la lista
  return (
    <div>
      <h1>List App</h1>
      <ul>
        {list.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
      <form onSubmit={handleSubmit}>
        <input type="text" value={text} onChange={handleChange} />
        <button type="submit">Add</button>
      </form>
    </div>
  );
}

export default ListApp;
