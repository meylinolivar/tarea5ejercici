import React, { useState } from "react";

function FormApp() {
  // Definimos el estado inicial de los campos del formulario como cadenas vacías
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");

  // Función que se llama cuando se envía el formulario para mostrar los valores de los campos en la consola
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevenimos el comportamiento predeterminado del formulario para evitar que la página se recargue

    console.log(`Name: ${name}`);
    console.log(`Email: ${email}`);
    console.log(`Phone: ${phone}`);
    console.log(`Message: ${message}`);

    // Reseteamos los valores de los campos del formulario a cadenas vacías
    setName("");
    setEmail("");
    setPhone("");
    setMessage("");
  };

  // Funciones que se llaman cuando se cambia el valor de los campos del formulario
  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handlePhoneChange = (event) => {
    setPhone(event.target.value);
  };

  const handleMessageChange = (event) => {
    setMessage(event.target.value);
  };

  // Renderizamos la aplicación, que consiste en un formulario con cuatro campos para nombre, correo electrónico, teléfono y mensaje
  return (
    <div>
      <h1>Form App</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input type="text" value={name} onChange={handleNameChange} />
        </label>
        <br />
        <label>
          Email:
          <input type="email" value={email} onChange={handleEmailChange} />
        </label>
        <br />
        <label>
          Phone:
          <input type="tel" value={phone} onChange={handlePhoneChange} />
        </label>
        <br />
        <label>
          Message:
          <textarea value={message} onChange={handleMessageChange} />
        </label>
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default FormApp;
